
from django.contrib import admin
from django.urls import include, path

urlpatterns = [ #보조 members 여기서 그url을 사용할수 잇게 해줌
    path('',include('members.urls')),#'도메인'
    path('admin/', admin.site.urls),
]
