from django.db import models
# sql때문에 Structured구조화된
# Query질의 질문
# Language언어
class Member(models.Model):
  firstname = models.CharField(max_length=255)
  lastname = models.CharField(max_length=255)
  phone = models.IntegerField(null=True)
  joined_date = models.DateField(null=True)
  image = models.ImageField(upload_to='member_images/', null=True, blank=True)

  def __str__(self): #화면에 값이 다보입니다
    return f"{self.firstname}{self.lastname}"
