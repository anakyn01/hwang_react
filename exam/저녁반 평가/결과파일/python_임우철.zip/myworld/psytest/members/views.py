from django.http import HttpResponse, HttpResponseRedirect
#"내가 만든 화면을 사용자의 인터넷 브라우저(크롬, 사파리 등)로
# 안전하게 보내주는 배달 상자"
from django.template import loader #다른폴더에 있는 html파일을 부르기 위해서
#1. 재료 준비하기 (Import)

from django.shortcuts import render, get_object_or_404
#복잡한 구문을 간단하게 설정

#모델 선언하기
from .models import Member #모델에 대한 정보를 가져옴

#class공부
class Fruit:
    name = "Apple"
    color = "red"

class Nums:
    x = 5
    y = 10


def cla(request): #우리가 오늘 학습할 클래스에 대해서 적는 페이지
    fruit_obj = Fruit()#변수명 fruit_obj 만들고 class Fruit대입
    nums_obj = Nums()#변수명 nums_obj를 만들고 class Nums대입

    #템플릿 로드
    template = loader.get_template('class.html')
    #컨텍스트 생성(키:'fruit_obj',값은:'인스턴스')
    context = {
        'fruit': fruit_obj
    }
    return HttpResponse(template.render(context, request))

#메인페이지 만들기
def index(request):
    template = loader.get_template('index.html')
    return HttpResponse(template.render())

#2. 주문을 받는 직원 만들기 (Function)
def members(request):
    mymembers = Member.objects.all().values()
#맴버 테이블에 있는 모든 회원정보를 파이선의 딕셔너리 형태로 싹 다 가져와줘

    #3. 창고에서 설계도 꺼내오기 (Get Template)
    template = loader.get_template('member.html')
    #백앤드 파이선에서 준비한 데이터를
    #html파일로 포장하기 위한 단계

    context = {'mymembers':mymembers,}
    '''
    Member : 데이터베이스 테이블 이름
    objects.all() :모든 데이터를 다 가져오라는 명령어
    .values() : 데이터를 어떤 형태로 변환(포멧팅)할지 정하는 부분
    파이썬 딕셔너리 형태
    '''
#4. 요리하고 손님에게 서빙하기 (Render & Response)
    return HttpResponse(template.render(context, request))

def testing(request):
    template = loader.get_template('test.html')
    context = {
        'firstname':'영일',
        'lastname':'황',
    }
    return HttpResponse(template.render(context, request))

def details(request, id):
    mymember = get_object_or_404(Member, id=id)
    context = {
        'mymember':mymember,
    }
    return render(request, 'details.html', context)
'''
주석처리한 이유는 기초적인 html변경하는걸 보기 위함입니다
화면에서 보이는 걸 만들어주는것
Django 뷰는 HTTP요청을 받아 html문서와 같은 http응답을 반환하는 python 함수

from http.client import HTTPResponse

from django.shortcuts import render
from django.http import HttpResponse
#미리 만들어 놓은 기능중에 렌더와 응답을 불러온다

def members(request): #리턴을 실행하고 종료한다
    return HttpResponse("세계여 안녕")
# Create your views here.
'''
