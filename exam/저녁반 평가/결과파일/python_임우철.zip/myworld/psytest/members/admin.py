#디장고가 기본적으로 제공하는 관리자기능을 불러옴
from django.contrib import admin
#관리자 페이지 보이도록 모델을 설정
from .models import Member
#같은 폴더의(.)의 models.py라는 파일 안에 정의해둔 Member라는 
# 데이터 모델을 가져옵니다

#관리자사이트에 Member를 등록합니다
admin.site.register(Member)