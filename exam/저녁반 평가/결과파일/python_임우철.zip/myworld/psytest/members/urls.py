from django.urls import path #장고에 속한 urls에서 path를 임포트함
from . import views # . 현재파일이 있는 같은 폴더에서 views.py파일을 불러옴

# ⚠️ 1. 이 두 줄이 상단에 임포트 되어 있는지 꼭 확인하세요!
from django.conf import settings
from django.conf.urls.static import static

#웹요청이 들어왔을때 Django라는 프레임워크가 가장 먼저찾아보는 url매핑 규칙리스트 선언
urlpatterns = [
 #추가 index
 path('', views.index, name='index'),
 path('member/', views.members, name='members'),
 path('class/', views.cla, name='cla'),
 #(이라우팅 규칙{엔드포인트정의}, 뷰즈파이에 속한 멤버즈라는 함수실행, 유니크한 멤버즈라는 별명부여
path('test/', views.testing, name='test'),
path('member/details/<int:id>/', views.details, name='details'),
]


#Uniform Resource Locator : 인터넷상의 웹사이트나 파일의 주소
'''
프로토콜 (Scheme)https: 브라우저와 서버가 정보를 주고받는 통신방식
도메인 (domainname): www.youtube.com
경로(path) : /members
파라미터(Parameter):?id=na?pw=1234
주소끝에 ?를 붙여서 서버에 추가적으로 전달하는 데이터를
'''
# 2. ⚠️ 매우 중요: 기존 urlpatterns 리스트 "바깥"에 아래 코드를 더해줍니다.
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)